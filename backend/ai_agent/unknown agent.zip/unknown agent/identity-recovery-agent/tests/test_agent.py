from fastapi.testclient import TestClient

from app.database import clusters, records
from app.main import app

client = TestClient(app)


def setup_function():
    clusters.clear()


def test_probable_cluster():
    r = client.post("/identity/recover", json={"record_ids": ["H-781", "R-221", "S-442"]})
    assert r.status_code == 200
    body = r.json()
    assert body["identity_stage"] == "PROBABLE_IDENTITY"
    assert body["conflicts"] == []
    assert body["possible_identity"] == "Arun"
    assert body["identity_stage"] != "VERIFIED_PERSON"


def test_duplicate_cluster_not_created():
    ids = {"record_ids": ["H-781", "R-221"]}
    a = client.post("/identity/recover", json=ids).json()
    b = client.post("/identity/recover", json={"record_ids": ["R-221", "H-781"]}).json()
    assert a["cluster_id"] == b["cluster_id"]
    assert len(clusters) == 1


def test_unknown_record_404():
    r = client.post("/identity/recover", json={"record_ids": ["H-781", "NOPE"]})
    assert r.status_code == 404


def test_gender_and_timeline_conflict():
    records.append({
        "record_id": "T-1", "source_type": "SHELTER", "name": None, "partial_name": None,
        "age": 35, "gender": "female", "clothing": "blue shirt",
        "physical_description": "medium build, black hair", "location": "Shelter B",
        "origin_location": "Road X", "timestamp": "2026-10-08 09:00", "medical_condition": None,
    })
    try:
        body = client.post("/identity/recover", json={"record_ids": ["H-781", "T-1"]}).json()
    finally:
        records.pop()
    assert body["status"] == "REVIEW_REQUIRED"
    assert any("Gender" in c for c in body["conflicts"])
    assert any("Timeline" in c for c in body["conflicts"])
    assert body["identity_stage"] != "PROBABLE_IDENTITY"


def test_verify_flow_and_graph():
    cid = client.post("/identity/recover", json={"record_ids": ["H-781", "R-221", "S-442"]}).json()["cluster_id"]
    g = client.get(f"/clusters/{cid}/graph").json()
    assert any(e["relation"] == "similar" for e in g["edges"])
    v = client.post("/identity/verify", json={
        "cluster_id": cid, "verified_name": "Arun Kumar", "officer_name": "Officer"})
    assert v.json()["identity_stage"] == "VERIFIED_PERSON"
    again = client.post("/identity/verify", json={
        "cluster_id": cid, "verified_name": "Arun Kumar", "officer_name": "Officer"})
    assert again.status_code == 409
    assert client.get("/clusters/NOPE").status_code == 404
