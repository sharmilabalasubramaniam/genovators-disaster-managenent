import pytest
from fastapi.testclient import TestClient

from app import tools
from app.database import init_db
from app.matching import calculate_match, text_similarity


@pytest.fixture(autouse=True)
def fresh_db(tmp_path, monkeypatch):
    monkeypatch.setenv("RESQLINK_DB", str(tmp_path / "test.db"))
    monkeypatch.setenv("AUTHORITY_API_KEY", "secret")
    init_db(seed=True)


def test_fuzzy_description():
    assert text_similarity("Blue shirt and black pants", "Blue t-shirt and black trousers") > 0.9
    assert text_similarity("Blue shirt", "Grey kurta") < 0.3


def test_match_score_unnamed_record_is_capped_and_high():
    a = tools.find_possible_matches(1)
    assert a[0]["candidate_id"] == 2
    assert 70 <= a[0]["match_score"] <= 90


def test_conflicting_candidate_not_listed():
    ids = [c["candidate_id"] for c in tools.find_possible_matches(1)]
    assert 3 not in ids and 5 not in ids  # wrong age/gender/zone


def test_hospital_and_shelter_found_by_person_id():
    c = tools.find_possible_matches(1)[0]
    assert c["hospital_records"][0]["hospital"] == "City Government Hospital"
    assert c["shelter_records"][0]["shelter"] == "Relief Shelter A"


def test_gender_conflict_blocks():
    m = {"name": "A", "age": 30, "gender": "Male", "last_location": "Z", "description": "red shirt"}
    c = {"name": "Unknown", "age": 30, "gender": "Female", "last_location": "Z", "description": "red shirt"}
    r = calculate_match(m, c)
    assert r["score"] <= 49 and r["conflicts"]


def test_firewall_requires_human_verification():
    r = tools.run_firewall_for_case(1, 2)
    assert r["decision"] == "REVIEW"
    tools.record_human_verification(1, 2, True, False, "Officer A")
    assert tools.run_firewall_for_case(1, 2)["decision"] == "REVIEW"
    tools.record_human_verification(1, 2, True, True, "Officer A")
    assert tools.run_firewall_for_case(1, 2)["decision"] == "SAFE_TO_VERIFY"


def test_cannot_reunite_without_clearance():
    assert "error" in tools.mark_reunited(1, 2, "Officer A")


def test_api_human_endpoints_need_key():
    from app.main import app

    with TestClient(app) as client:
        body = {"missing_person_id": 1, "candidate_id": 2, "identity_verified": True,
                "relationship_verified": True, "verified_by": "Officer A"}
        assert client.post("/cases/verify", json=body).status_code == 401
        assert client.post("/cases/verify", json=body, headers={"X-Authority-Key": "secret"}).status_code == 200
        r = client.post("/cases/reunite", json={"missing_person_id": 1, "candidate_id": 2, "officer": "Officer A"},
                        headers={"X-Authority-Key": "secret"})
        assert r.status_code == 200 and r.json()["status"] == "REUNITED"


def test_agent_has_no_verification_tool():
    from app import agent

    names = {"search_people", "search_rescue", "get_records_for_person_id", "search_hospitals_by_name",
             "search_shelters_by_name", "find_matches", "check_firewall"}
    for n in names:
        tool_obj = getattr(agent, n)
        params = set(tool_obj.args.keys())
        assert not params & {"identity_verified", "relationship_verified", "timeline_consistent", "match_score"}
